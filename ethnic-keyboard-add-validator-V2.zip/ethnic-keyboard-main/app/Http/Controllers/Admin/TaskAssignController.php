<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTaskAssignRequest;
use App\Http\Requests\UpdateTaskAssignRequest;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\Directed;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DirectedTaskAssign;
use App\Models\District;
use App\Models\Group;
use App\Models\Language;
use App\Models\SpontaneousTaskAssign;
use App\Models\TaskAssign;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\User;
use App\Models\Village;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use File;

class TaskAssignController extends Controller
{

    public function taskAssignListByLanguage(){
        if(Auth::user()->hasRole(['Linguist','Validator'])){
            $taskAssignListByLanguages = TaskAssign::with(['language','district'])
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->get();

        }elseif(Auth::user()->hasRole(['Data Collector'])){
           $taskAssignListByLanguages= TaskAssign::with(['language','district','directedTasks.topic','spontaneousTasks.spontaneous'])
                ->where('user_id', auth()->id() )
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->get();
        }


        return view('admin.task_assign.taskAssignList', compact('taskAssignListByLanguages'));
    }

    public function index()
    {
        $taskAssigns= TaskAssign::with('topics', 'spontaneouses')->latest()->get();

        return view('admin.task_assign.index', compact('taskAssigns'));
    }


    public function create()
    {
//        $districts = District::pluck('name', 'id');
        $groups = Group::pluck('name', 'id');
        $languages = Language::pluck('name', 'id');
        $collectors= User::where('user_type', 4)->pluck('name', 'id');

        return view('admin.task_assign.create', compact('groups', 'languages', 'collectors'));
    }


    public function store(StoreTaskAssignRequest $request)
    {

        try {

            DB::beginTransaction();

            foreach ($request->input('user_id') as $a =>$i){

                $taskAssign = new TaskAssign();
                $taskAssign->user_id = $i;
                $taskAssign->group_id =$request->group_id;
                $taskAssign->language_id =$request->language_id;
                $taskAssign->district_id =$request->district;
                $taskAssign->upazila_id =$request->upazila;
                $taskAssign->union_id =$request->union;
                $taskAssign->village =$request->village;
                $taskAssign->total_sample =$request->total_sample;
                $taskAssign->start_date =$request->start_date;
                $taskAssign->end_date =$request->end_date;
                $taskAssign->created_by =auth()->id();
                $taskAssign->updated_by =0;
                $taskAssign->save();

                foreach ($request->input('topic_id'.$i) as $k=> $topicItem){
                    $directed = new DirectedTaskAssign();
                    $directed->task_assign_id = $taskAssign->id;
                    $directed->topic_id= $topicItem;
                    $directed->user_id= $i;
                    $directed->save();
                }
                foreach ($request->input('spontaneous_id'.$i) as $key=> $spontaneousItem){
                    $spontaneous = new SpontaneousTaskAssign();
                    $spontaneous->task_assign_id = $taskAssign->id;
                    $spontaneous->spontaneous_id= $spontaneousItem;
                    $spontaneous->user_id= $i;
                    $spontaneous->save();
                }

                // // Store User Token
                // $user = User::find($i);
                // $user->fcm_token = $request->user_token;
                // $user->save();
                // $this->Notification($n_title, $n_body);

                // Notification message

                $n_title = 'New Task Assign';
                $n_body  = 'You are assign for a new group task';

                Notification::create([

                    'user_id'     => $i,
                    'title'       => $n_title,
                    'body'        => $n_body,
                    'status'      => 0,
                    'created_by'  => Auth::user()->id
                ]);

            }

            DB::commit();

            return redirect()->route('admin.task_assigns.index')
                ->with('success', __('messages.গ্রুপ টাস্ক অ্যাসাইন সফলভাবে তৈরি করা হয়েছে।'));

        } catch (\Throwable $th) {

            DB::rollBack();
            // dd($th);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $groupTaskAssign = TaskAssign::findOrFail($id);
        $groups = DB::table('groups')
            ->join('group_collectors', 'groups.id', '=', 'group_collectors.group_id')
            ->where('group_id', $groupTaskAssign->group_id)
            ->select('groups.*')
            ->pluck('name', 'id');

        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $groupTaskAssign->group_id)
            ->where('user_id', $groupTaskAssign->user_id)
            ->select('users.*')
            ->pluck('name', 'id');

        $languages = Language::pluck('name', 'id');
        $districts = DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $groupTaskAssign->language_id)
            ->select('districts.*')
            ->pluck('name', 'id');

        $upazilas = Upazila::where([
            ['district_id', '=', $groupTaskAssign->district_id],
        ])->pluck('name', 'id');

        $unions = Union::where([
            ['upazila_id', '=', $groupTaskAssign->upazila_id],
        ])->pluck('name', 'id');

        /* $villages = Village::where([
             ['union_id', '=', $groupTaskAssign->union_id],
         ])->pluck('name', 'id');*/

        $directeds = DirectedTaskAssign::with('topic')->where([
            ['task_assign_id', '=', $groupTaskAssign->id],
        ])->get();

        $spontaneouses = SpontaneousTaskAssign::with('spontaneous')->where([
            ['task_assign_id', '=', $groupTaskAssign->id],
        ])->get();


        return view('admin.task_assign.edit',
            compact('groupTaskAssign', 'collectors','districts', 'groups', 'languages', 'upazilas', 'unions', 'directeds','spontaneouses'));
    }


    public function update(UpdateTaskAssignRequest $request, $id)
    {
        $groupTaskAssign = TaskAssign::findOrFail($id);
        $groupTaskAssign->user_id =$request->user_id;
        $groupTaskAssign->group_id =$request->group_id;
        $groupTaskAssign->language_id =$request->language_id;
        $groupTaskAssign->district_id =$request->district;
        $groupTaskAssign->upazila_id =$request->upazila;
        $groupTaskAssign->union_id =$request->union;
        $groupTaskAssign->village =$request->village;
        $groupTaskAssign->total_sample =$request->total_sample;
        $groupTaskAssign->start_date =$request->start_date;
        $groupTaskAssign->end_date =$request->end_date;
        $groupTaskAssign->updated_by =auth()->id();
        $groupTaskAssign->update();

        $directedArray =[];
        $spontaneousArray =[];
        $directedSingleTaskAssignIDs = DirectedTaskAssign::where('task_assign_id',$groupTaskAssign->id)->get();
        if ($directedSingleTaskAssignIDs){
            foreach ($directedSingleTaskAssignIDs as $data){
                $directedArray[]= $data->topic_id;
            }
        }

        $SpontaneousSingleTaskAssignIDs = SpontaneousTaskAssign::where('task_assign_id',$groupTaskAssign->id)->get();
        if ($SpontaneousSingleTaskAssignIDs){
            foreach ($SpontaneousSingleTaskAssignIDs as $value){
                $spontaneousArray[]= $value->spontaneous_id;
            }
        }

        foreach ($request->input('topic_id') as $k=> $topicItem){
            DirectedTaskAssign::updateOrCreate([
                'task_assign_id'=>$groupTaskAssign->id,
                'topic_id'=>$topicItem,
                'user_id'=>$request->user_id,
            ]);
        }

        foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
            SpontaneousTaskAssign::updateOrCreate([
                'task_assign_id'=>$groupTaskAssign->id,
                'spontaneous_id'=>$spontaneousItem,
                'user_id'=>$request->user_id,
            ]);
        }

        foreach ($directedArray as $directedTopic){
            if (!in_array($directedTopic, $request->topic_id)){
                DirectedTaskAssign::where('task_assign_id',$groupTaskAssign->id)->where('topic_id', $directedTopic)->delete();
            }
        }
        foreach ($spontaneousArray as $spontaneous){
            if (!in_array($spontaneous, $request->spontaneous_id)){
                SpontaneousTaskAssign::where('task_assign_id',$groupTaskAssign->id)->where('spontaneous_id', $spontaneous)->delete();
            }
        }

        return redirect()->back()
            ->with('success', __('messages.টাস্ক অ্যাসাইন সফলভাবে আপডেট করা হয়েছে।'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $taskAssign = TaskAssign::findOrFail($id);
        $taskAssign->delete();
        SpontaneousTaskAssign::where('task_assign_id', $id )->delete();
        DirectedTaskAssign::where('task_assign_id', $id)->delete();
        $dataCollections =DataCollection::where('task_assign_id', $id)->get();
        if (!$dataCollections->isEmpty()){
            foreach ($dataCollections as $dataDollectionID){
                $dcDirected = DCDirected::where('data_collection_id', $dataDollectionID->id)->first();
                if (!empty($dcDirected)){
                    $dcDirectedSentence = DCDirectedSentence::where('d_c_directed_id', $dcDirected->id)->first();
                    $audioPath = public_path($dcDirectedSentence->audio);
                     if(File::exists($audioPath)) {
                         File::delete($audioPath);
                     }
                    $autdioTrims= AudioTrim::where('d_c_directed_sentences_id', $dcDirectedSentence->id)->get();
                    foreach ($autdioTrims as $trimID){
                        $audioPathTrim = public_path($trimID->audio);
                        if(File::exists($audioPathTrim)) {
                            File::delete($audioPathTrim);
                        }
                        $trimID->delete();
                    }
                    $dcDirected->delete();
                    $dcDirectedSentence->delete();
                    $dataDollectionID->delete();


                }else{

                    $dcSpontaneous= DCSpontaneous::where('data_collection_id', $dataDollectionID->id)->first();
                     $audioPath = public_path($dcSpontaneous->audio);
                     if(File::exists($audioPath)) {
                         File::delete($audioPath);
                     }
                    $autdioTrims= AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneous->id)->get();
                    foreach ($autdioTrims as $trimID){
                        $audioPathTrim = public_path($trimID->audio);
                        if(File::exists($audioPathTrim)) {
                            File::delete($audioPathTrim);
                        }
                        $trimID->delete();
                    }
                    $dcSpontaneous->delete();
                    $dataDollectionID->delete();
                }
            }
        }

        return redirect()->back()->with('success', __('messages.টাস্ক অ্যাসাইন সফলভাবে মুছে ফেলা হয়েছে।'));
    }


    public function getCollector(Request $request){
        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $request->group_id)
            ->select('users.*')
            ->pluck('name', 'id');
//        return $collectors;
        return $data= view('admin.task_assign.renderGroup',compact('collectors'))->render();
    }

    public function getGroupByCollector(Request $request){
        /*return Group::with(['assign','member'=>function($a){$a->with(['collectors']);}])
         //->whereHas('group',function ($a)use ($request){};))
            ->findOrFail($request->group_id);*/

        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $request->group_id)
            ->select('users.*')
            ->pluck('name', 'id');
        return response()->json($collectors);
    }

    public function getDirectedTopic(Request $request){

        $topics= DB::table('topics')
            ->join('directed_languages', 'topics.id', '=', 'directed_languages.topic_id')
            ->where('language_id', $request->language_id)
            ->select('topics.*')
            ->pluck('name', 'id');
        return response()->json($topics);
    }

    public function getSpontaneous(Request $request){
        $spontaneouses= DB::table('spontaneouses')
            ->join('spontaneous_languages', 'spontaneouses.id', '=', 'spontaneous_languages.spontaneous_id')
            ->where('language_id', $request->language_id)
            ->select('spontaneouses.*')
            ->pluck('word', 'id');
        return response()->json($spontaneouses);
    }


    public function getUpazila(Request $request){

        $upazilas = Upazila::where('district_id', $request->district_id)->pluck('name', 'id');

        return response()->json($upazilas);

    }


    public function getUnion(Request $request){

        $unions = Union::where('upazila_id', $request->upazila_id)->pluck('name', 'id');

        return response()->json($unions);

    }

    public function getVillage(Request $request){
        $villages= Village::where('union_id', $request->union_id)->pluck('name', 'id');

        return response()->json($villages);
    }


    public function getDirectedByLanguage(){

    }


    public function getDirectedTaskByLanguage($id){
        $directedTaskLanguages=DirectedTaskAssign::with('taskAssign.language', 'taskAssign.district', 'topic.directeds')
            ->where('task_assign_id', $id)->get();

        $firstItem = Arr::first($directedTaskLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.task_assign.directedList', compact('directedTaskLanguages', 'firstItem'));
    }

    public function getSpontaneousTaskByLanguage($id){
        $spontaneousTaskLanguages=SpontaneousTaskAssign::with('taskAssign.language', 'taskAssign.district', 'spontaneous')->where('task_assign_id', $id)->get();

        $firstItem = Arr::first($spontaneousTaskLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.task_assign.spontaneousList', compact('spontaneousTaskLanguages', 'firstItem'));
    }
}
