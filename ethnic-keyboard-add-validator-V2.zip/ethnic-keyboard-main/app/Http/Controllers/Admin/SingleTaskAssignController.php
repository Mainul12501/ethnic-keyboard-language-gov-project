<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\Group;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\Village;
use App\Models\District;
use App\Models\Language;
use App\Models\TaskAssign;
use App\Models\Notification;
use Illuminate\Http\Request;
use App\Models\DataCollector;
use App\Models\LanguageDistrict;
use App\Models\SingleTaskAssign;
use App\Traits\SendNotification;
use App\Models\DirectedTaskAssign;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\SpontaneousTaskAssign;
use App\Models\DirectedSingleTaskAssign;
use App\Models\SpontaneousSingleTaskAssign;
use App\Http\Requests\StoreSingleTaskAssignRequest;

class SingleTaskAssignController extends Controller
{
    use SendNotification;
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $languages = Language::pluck('name', 'id');
        $collectors= User::where('user_type', 4)->pluck('name', 'id');

        return view('admin.single_task_assign.create', compact('languages', 'collectors'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSingleTaskAssignRequest $request)
    {

        try {

            DB::beginTransaction();

            $singleTaskAssign = new TaskAssign();
            $singleTaskAssign->user_id =$request->user_id;
            $singleTaskAssign->language_id =$request->language_id;
            $singleTaskAssign->district_id =$request->district;
            $singleTaskAssign->upazila_id =$request->upazila;
            $singleTaskAssign->union_id =$request->union;
            $singleTaskAssign->village =$request->village;
            $singleTaskAssign->total_sample =$request->total_sample;
            $singleTaskAssign->start_date =$request->start_date;
            $singleTaskAssign->end_date =$request->end_date;
            $singleTaskAssign->created_by =auth()->id();
            $singleTaskAssign->updated_by =0;
            $singleTaskAssign->save();

            foreach ($request->input('topic_id') as $k=> $topicItem){
                $directed = new DirectedTaskAssign();
                $directed->task_assign_id = $singleTaskAssign->id;
                $directed->topic_id= $topicItem;
                $directed->user_id= $request->user_id;
                $directed->save();
            }

            foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
                $spontaneous = new SpontaneousTaskAssign();
                $spontaneous->task_assign_id = $singleTaskAssign->id;
                $spontaneous->spontaneous_id= $spontaneousItem;
                $spontaneous->user_id= $request->user_id;
                $spontaneous->save();
            }

            // // Store User Token
            $user = User::find($request->user_id);
            // $user->fcm_token = $request->user_token;
            // $user->save();

            // // Notification message
            $n_title = 'New Task Assign';
            $n_body  = 'Dear'.' '.$user->name.', '.'You are assign for a new task';
            // $this->Notification($n_title, $n_body);


            // Sending Notification


            Notification::create([

                'user_id'     => $request->user_id,
                'title'       => $n_title,
                'body'        => $n_body,
                'status'      => 0,
                'created_by'  => Auth::user()->id
            ]);

            DB::commit();

            return redirect()->route('admin.task_assigns.index')
            ->with('success', 'Task Assign has been created Successfully');

        } catch (\Throwable $th) {
//             dd($th);
            DB::rollback();
            return redirect()->back();

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(TaskAssign $singleTaskAssign)
    {
        $collectors= DB::table('users')
            ->join('task_assigns', 'users.id', '=', 'task_assigns.user_id')
            ->where('user_id', $singleTaskAssign->user_id)
            ->select('users.*')
            ->pluck('name', 'id');

        $districts = DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $singleTaskAssign->language_id)
            ->select('districts.*')
            ->pluck('name', 'id');

        $languages = Language::pluck('name', 'id');
        $upazilas = Upazila::where([
            ['district_id', '=', $singleTaskAssign->district_id],
        ])->pluck('name', 'id');

        $unions = Union::where([
            ['upazila_id', '=', $singleTaskAssign->upazila_id],
        ])->pluck('name', 'id');

        $villages = Village::where([
            ['union_id', '=', $singleTaskAssign->union_id],
        ])->pluck('name', 'id');

        $directeds = DirectedTaskAssign::with('topic')->where([
            ['task_assign_id', '=', $singleTaskAssign->id],
        ])->get();

        $spontaneouses = SpontaneousTaskAssign::with('spontaneous')->where([
            ['task_assign_id', '=', $singleTaskAssign->id],
        ])->get();
//        return$spontaneouses;

        return view('admin.single_task_assign.edit',
            compact('singleTaskAssign', 'collectors', 'districts', 'languages', 'upazilas', 'unions', 'villages', 'directeds', 'spontaneouses'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreSingleTaskAssignRequest $request, TaskAssign $singleTaskAssign)
    {
        $singleTaskAssign->user_id =$request->user_id;
        $singleTaskAssign->language_id =$request->language_id;
        $singleTaskAssign->district_id =$request->district;
        $singleTaskAssign->upazila_id =$request->upazila;
        $singleTaskAssign->union_id =$request->union;
        $singleTaskAssign->village =$request->village;
        $singleTaskAssign->total_sample =$request->total_sample;
        $singleTaskAssign->start_date =$request->start_date;
        $singleTaskAssign->end_date =$request->end_date;
        $singleTaskAssign->updated_by =auth()->id();
        $singleTaskAssign->update();

        $directedArray =[];
        $spontaneousArray =[];
        $directedSingleTaskAssignIDs = DirectedTaskAssign::where('task_assign_id',$singleTaskAssign->id)->get();
        if ($directedSingleTaskAssignIDs){
            foreach ($directedSingleTaskAssignIDs as $data){
                $directedArray[]= $data->topic_id;
            }
        }

        $SpontaneousSingleTaskAssignIDs = SpontaneousTaskAssign::where('task_assign_id',$singleTaskAssign->id)->get();
        if ($SpontaneousSingleTaskAssignIDs){
            foreach ($SpontaneousSingleTaskAssignIDs as $value){
                $spontaneousArray[]= $value->spontaneous_id;
            }
        }

        foreach ($request->input('topic_id') as $k=> $topicItem){
            DirectedTaskAssign::updateOrCreate([
                'task_assign_id'=>$singleTaskAssign->id,
                'topic_id'=>$topicItem,
                'user_id'=>$request->user_id,
            ]);
        }

        foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
            SpontaneousTaskAssign::updateOrCreate([
                'task_assign_id'=>$singleTaskAssign->id,
                'spontaneous_id'=>$spontaneousItem,
                'user_id'=>$request->user_id,
            ]);
        }

        foreach ($directedArray as $directedTopic){
            if (!in_array($directedTopic, $request->topic_id)){
                DirectedTaskAssign::where('task_assign_id',$singleTaskAssign->id)->where('topic_id', $directedTopic)->delete();
            }
        }
        foreach ($spontaneousArray as $spontaneous){
            if (!in_array($spontaneous, $request->spontaneous_id)){
                SpontaneousTaskAssign::where('task_assign_id',$singleTaskAssign->id)->where('spontaneous_id', $spontaneous)->delete();
            }
        }


        return redirect()->back()
            ->with('success', 'Single Task Assign has been updated Successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

    }



    public function getDistrict(Request $request){
       // $districts= LanguageDistrict::where('language_id', $request->language_id)->with('district')->get();

        $districts= DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $request->language_id)
            ->select('districts.*')
            ->pluck('name', 'id');


        return response()->json($districts);
    }


}
