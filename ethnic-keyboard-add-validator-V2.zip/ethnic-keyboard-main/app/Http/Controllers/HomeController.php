<?php

namespace App\Http\Controllers;


use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\Directed;
use App\Models\DirectedTaskAssign;
use App\Models\SpontaneousTaskAssign;
use App\Models\Language;
use App\Models\Notification;
use App\Models\Speaker;
use App\Models\Spontaneous;
use App\Models\TaskAssign;
use App\Models\Topic;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
//use function PHPUnit\Framework\isEmpty;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $allUsers =User::count();
        $languageCounts= Language::withCount(['directedLanguage','spontaneousLanguage'])->get();
        $totalSpeakers = Speaker::where('created_by', auth()->id())->count();
        $totalCollections= '';
        $notifications='';
        $totalLanguages= '';
        $totalDirectedTopics= '';
        $totalDirectedSentences= '';
        $totalSpontaneous= '';
        $totalCollectors='';
        $notificationCounts='';
        $todayDirecteds='';
        $todayDirctedCounts='';
        $todayDataCollections='';
        $todaycollections='';
        $todaySpontaneouses='';
        $todaySpontaneouCounts='';
        $taskAssignByLanguage='';
        $taskBycollections='';
        $totalLang='';
        $totalDirected='';
        $totalSpon='';
        $totalPendingSpon='';
        $totalDirPending='';



        if (auth()->user()->user_type == 4){
            $totalCollectors ='';

            $directeds = DCDirectedSentence::where('status', 0)->where('created_by', auth()->id())->whereNotNull('approved_by')->count();
            $spontaneouses=DCSpontaneous::where('status', 0)->where('created_by', auth()->id())->whereNotNull('approved_by')->count();
            $totalPending =$directeds+$spontaneouses;

            $todayDataCollections = DataCollection::where('created_by', auth()->id())->whereDate('created_at', '=', Carbon::today()->toDateString())
                ->with(['language','collector', 'dcSpontaneous.spontaneous', 'dcDirected'=>function($q){
                    $q->with('topic','dcSentence.directed')->get();
                } ])->latest()->paginate(3);

            $totalCollections = DataCollection::where('created_by', auth()->id())->count();
            $todaycollections = DataCollection::where('collector_id', auth()->id())->whereDate('created_at', '=', Carbon::today()->toDateString())
                ->count();
            $totalLang= TaskAssign::where('user_id', auth()->id())->distinct('language_id')->count('language_id');
            $totalDirected=DirectedTaskAssign::where('user_id', auth()->id())->count('topic_id');

            $collectedDirNumber= DCDirected::join('data_collections', 'data_collections.id', '=', 'd_c_directeds.data_collection_id')
                ->select('topic_id','data_collections.id', 'data_collections.task_assign_id',DB::raw('COUNT(*) AS total_sentence'))
                ->where('data_collections.collector_id', auth()->id())
                ->groupBy('topic_id','data_collections.task_assign_id')
                ->get();

            $totalDirPending= $totalDirected- count($collectedDirNumber);
            $totalSpon=SpontaneousTaskAssign::where('user_id', auth()->id())->count('spontaneous_id');
            $collectedSponNumber=DataCollection::where('collector_id', auth()->id())
                ->where('type_id', 2)
                ->count();
            $totalPendingSpon=$totalSpon-$collectedSponNumber;


            /*return $tasks = TaskAssign::selectRaw( 'language_id', \DB::raw("COUNT(*) as count"))->where('user_id', Auth::id())
                ->with('language')
                ->orderBy('language_id')->get();*/


            $taskAssignByLanguage= TaskAssign::with(['directedTasks.topic'=>function ($query){
                $query->withCount('directeds');

            }, 'spontaneousTasks.spontaneous','language',
                'district','upazila', 'union', 'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'])
                ->where('user_id', auth()->id() )
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->limit(6)
                ->get();


                


            $taskBycollections = TaskAssign::with(['speakers','collector', 'validators','directedTasks.topic'=>function($q){
                $q->withCount('directeds');
            },
                'spontaneousTasks.spontaneous','language',
                'district', /* 'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'*/])
                ->where('user_id', auth()->id() )
                ->withCount('directedTasks', 'spontaneousTasks')
                ->latest()
                ->paginate(8);

            $notifications = Notification::where('user_id', auth()->id())->latest()->limit(5)->get();
            $notificationCounts =Notification::where('user_id', auth()->id())->count();


            $approvedDirecteds=DCDirectedSentence::where('status', 1)->where('created_by', auth()->id())->count();
            $approvedSpontaneouses=DCSpontaneous::where('status', 1)->where('created_by', auth()->id())->count();
            $totalApproved= $approvedDirecteds+$approvedSpontaneouses;

        }elseif (Auth::user()->hasRole(['Linguist','Validator'])){

            $todayDirecteds = Directed::with('topics')->where('created_by', auth()->id())
                ->whereDate('created_at', '=', Carbon::today()->toDateString())->paginate(5);
            $todayDirctedCounts = $todayDirecteds->count();

            $todaySpontaneouses =Spontaneous::where('created_by', auth()->id())
                ->whereDate('created_at', '=', Carbon::today()->toDateString())->paginate(5);
            $todaySpontaneouCounts =$todaySpontaneouses->count();

            $totalLanguages=Language::count();
            $totalDirectedTopics=Topic::count();
            $totalDirectedSentences= Directed::count();
            $totalSpontaneous = Spontaneous::count();

            $taskAssignByLanguage= TaskAssign::with(['directedTasks.topic'=>function ($query){
                $query->withCount('directeds');

            }, 'spontaneousTasks.spontaneous','language',
                'district','upazila', 'union', 'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'])
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->limit(6)
                ->get();
            // dd($taskAssignByLanguage->toArray());

            $taskBycollections = TaskAssign::with(['speakers','collector', 'validators', 'directedTasks.topic'=>function($q){
                $q->with('directeds');
                $q->withCount('directeds');
            },
                'spontaneousTasks.spontaneous','language',
                'district', /*'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'*/])
                ->withCount('directedTasks', 'spontaneousTasks')
                ->latest()
                ->paginate(8);
//            dd($taskBycollections->toArray());

            $notifications = Notification::where('user_id', auth()->id())->latest()->limit(5)->get();
            $notificationCounts =Notification::where('user_id', auth()->id())->count();


            $directeds = DCDirectedSentence::where('status', 0)->whereNotNull('approved_by')->count();
            $spontaneouses=DCSpontaneous::where('status', 0)->whereNotNull('approved_by')->count();
            $totalPending =$directeds+$spontaneouses;

            $approvedDirecteds=DCDirectedSentence::where('status', 1)->count();
            $approvedSpontaneouses=DCSpontaneous::where('status', 1)->count();
            $totalApproved= $approvedDirecteds+$approvedSpontaneouses;

        }else{

            $totalCollectors = User::where('user_type', 4)->count();
            $directeds = DCDirectedSentence::where('status', 0)->whereNotNull('approved_by')->count();
            $spontaneouses=DCSpontaneous::where('status', 0)->whereNotNull('approved_by')->count();
            $totalPending =$directeds+$spontaneouses;

            $totalCollections = DataCollection::count();

            $todayDataCollections = DataCollection::whereDate('created_at', '=', Carbon::today()->toDateString())
                ->with(['language','collector', 'dcSpontaneous.spontaneous', 'dcDirected'=>function($q){
                    $q->with('topic','dcSentence.directed')->get();
                } ])->latest()->paginate(3);

            $todaycollections = DataCollection::whereDate('created_at', '=', Carbon::today()->toDateString())
                ->count();


            $taskAssignByLanguage = Language::withCount(['taskAssign'])->get();

            $approvedDirecteds=DCDirectedSentence::where('status', 1)->count();
            $approvedSpontaneouses=DCSpontaneous::where('status', 1)->count();
            $totalApproved= $approvedDirecteds+$approvedSpontaneouses;

        }

        /*$pieChart = DataCollection::select(\DB::raw("COUNT(*) as count"), \DB::raw("MONTHNAME(created_at) as month_name"))
            ->whereYear('created_at', date('Y'))
            ->groupBy('month_name')
            ->orderBy('count')
            ->get();*/

        $barDirecteds =Language::with(['dataCollection'=>function($query){
            $query->with(['dcDirected.dcSentence'=>function($q){
                $q->whereNotNull('approved_by')->get();
            }])->where('type_id', 1)->get();
        }])
            ->get();


        $barSpontaneous =Language::with(['dataCollection'=>function($query){
            $query->where('type_id', 2)->get();
        }])
            ->get();

        $languages = Language::pluck('name', 'id');

        return view('dashboard',
            compact('allUsers', 'languageCounts', 'totalApproved', 'totalPending', 'totalCollectors',
                'todayDataCollections', 'todaycollections', 'totalCollections', 'barDirecteds','barSpontaneous',
                'languages','totalSpeakers', 'taskAssignByLanguage', 'notifications','notificationCounts', 'totalLanguages',
                'totalDirectedTopics','totalDirectedSentences', 'totalSpontaneous', 'todayDirecteds', 'todayDirctedCounts',
                'todaySpontaneouses', 'todaySpontaneouCounts', 'taskBycollections',
                'todaySpontaneouses', 'todaySpontaneouCounts',
                'totalLang','totalDirected','totalSpon','totalPendingSpon','totalDirPending'));

    }

    /*public function languageDemo(){
        return view('languageDemo');
    }*/
}
