@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.task_assigns.index')}}">{{__('messages.টাস্ক অ্যাসাইন')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.এডিট')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                {{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}
                <form action="{{route('admin.single_task_assigns.update', $singleTaskAssign->id)}}" method="post" >
                    @csrf
                    @method("PUT")
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="user_id">{{__('messages.ডাটা কালেক্টর')}}<span class="text-danger">*</span> </label>
                        <div class="col-md-10 col-sm-9">
                            @foreach($collectors as $key => $collector)
                                <input id="user_id" type="text" name="user_id" value="{{$key}}" hidden>
                                <input class="form-control @error('user_id') is-invalid @enderror" type="text"  value="{{$collector}}" readonly>
                            @endforeach
                            {{--<select class="form-select @error('user_id') is-invalid @enderror"  id="user_id" name="user_id">
                                @foreach($collectors as $key => $collector)
                                    <option value="{{$key}}" {{($key == $groupTaskAssign->user_id)? 'selected': ''}}>{{$collector}}</option>
                                @endforeach
                            </select>--}}
                            @error('user_id')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="language_id">{{__('messages.ভাষার নাম')}}<span class="text-danger">*</span></label>
                        <div class="col-md-10 col-sm-9">
                            <select class="form-select  @error('language_id') is-invalid @enderror"  id="language_id" name="language_id">
                                <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                @foreach($languages as $key => $value)
                                    <option value="{{$key}}" {{($key == $singleTaskAssign->language_id)? 'selected': ''}}>{{$value}}</option>
                                @endforeach
                            </select>
                            @error('language_id')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="district">{{__('messages.জেলা')}}<span class="text-danger">*</span></label>
                        <div class="col-md-10 col-sm-9">
                            <select class="form-select @error('district') is-invalid @enderror" id="district"  name="district">
                                <option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>
                                @foreach($districts as $key => $district)
                                    <option value="{{$key}}" {{($key == $singleTaskAssign->district_id)? 'selected': ''}}>{{$district}}</option>
                                @endforeach
                            </select>
                            @error('district')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="upazila">{{__('messages.উপজেলা')}}<span class="text-danger">*</span></label>
                        <div class="col-md-10 col-sm-9">
                            <select class="form-select @error('upazila') is-invalid @enderror" id="upazila" name="upazila">
                                <option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>
                                @foreach($upazilas as $key => $upazila)
                                    <option value="{{$key}}" {{($key == $singleTaskAssign->upazila_id)? 'selected': ''}}>{{$upazila}}</option>
                                @endforeach
                            </select>
                            @error('upazila')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="union">{{__('messages.ইউনিয়ন')}}<span class="text-danger">*</span></label>
                        <div class="col-md-10 col-sm-9">
                            <select class="form-select @error('union') is-invalid @enderror" id="union" name="union">
                                <option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>
                                @foreach($unions as $key => $union)
                                    <option value="{{$key}}" {{($key == $singleTaskAssign->union_id)? 'selected': ''}}>{{$union}}</option>
                                @endforeach
                            </select>
                            @error('union')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="village">{{__('messages.গ্রাম')}}</label>
                        <div class="col-md-10 col-sm-9">
                            <input class="form-control @error('village') is-invalid @enderror" id="village" placeholder="{{__('messages.গ্রাম')}}" type="text" name="village" value="{{$singleTaskAssign->village}}">
                            @error('village')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-md-2 col-sm-3 col-form-label" for="total_sample">{{__('messages.মোট নমুনা')}}</label>
                        <div class=" col-md-10 col-sm-9">
                            <input class="form-control @error('total_sample') is-invalid @enderror" id="total_sample" type="number" name="total_sample" value="{{$singleTaskAssign->total_sample}}">
                            @error('total_sample')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                    </div>
                    <div class="mb-3 row " >
                        <div class="col-md-6 col-sm-12 row mb-3">
                            <label class="col-md-4 col-sm-3 col-form-label" for="start_date">{{__('messages.শুরুর তারিখ')}}</label>
                            <div class=" col-md-8 col-sm-9">
                                <input class="form-control @error('start_date') is-invalid @enderror" id="start_date" type="date" name="start_date" value="{{$singleTaskAssign->start_date}}">
                                @error('start_date')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 row">
                            <label class="col-md-4 col-sm-3 col-form-label" for="end_date">{{__('messages.শেষ তারিখ')}}</label>
                            <div class="col-md-8 col-sm-9">
                                <input class="form-control @error('end_date') is-invalid @enderror" id="end_date" type="date"  name="end_date" value="{{$singleTaskAssign->end_date}}">
                                @error('end_date')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="field_wrapper">
                                <div class="row mb-3" >
                                    <div class="col-md-6 col-sm-6">
                                        <label for="topic_id" class="">{{__('messages.নির্দেশিত')}}<span class="text-danger">*</span></label>
                                        <select class="form-select @error('topic_id') is-invalid @enderror"  id="topic_id" name="topic_id[]" multiple>
                                            @foreach($directeds as $key => $directed)
                                                <option value="{{$directed->topic->id}}" selected>{{$directed->topic->name}}</option>
                                            @endforeach
                                        </select>
                                        @error('topic_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <label for="spontaneous_id" class="">{{__('messages.স্বতঃস্ফূর্ত')}}<span class="text-danger">*</span></label>
                                        <select class="form-select @error('spontaneous_id') is-invalid @enderror" id="spontaneous_id" name="spontaneous_id[]" multiple>
                                            @foreach($spontaneouses as $key => $spontaneousItem)
                                                <option value="{{$spontaneousItem->spontaneous->id}}" selected>{{$spontaneousItem->spontaneous->word}}</option>
                                            @endforeach
                                        </select>
                                        @error('spontaneous_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('group-task-assgin-js')
    <script type="text/javascript">
        $(document).ready(function() {
            // select directed
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                // console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getDirectedTopic')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[id="topic_id"]').empty();
                            $('#topic_id').append('<option value="">{{__('messages.নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[id="topic_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[id="topic_id"]').empty()
                }
            });

            // select spontaneous
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                // console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getSpontaneous')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="spontaneous_id[]"]').empty();
                            $('#sponataneous_id').append('<option value="">{{__('messages.নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[id="spontaneous_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[id="spontaneous_id]"]').empty()

                }
            });

            // select Districts
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getDistrict')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="district"]').empty();
                            $('select[name="upazila"]').empty()
                            $('select[name="union"]').empty();
                            $('select[name="village"]').empty();
                            $('#district').append('<option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="district"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="district"]').empty()
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                    $('select[name="village"]').empty();
                }
            });

            // select upazila
            $('#district').change(function() {
                var districtID = $(this).val();
                console.log(districtID);
                if(districtID) {
                    $.ajax({
                        url:"{{url('admin/getUpazila')}}?district_id="+districtID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="upazila"]').empty();
                            $('#upazila').append('<option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="upazila"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                    $('select[name="village"]').empty();
                }
            });

            // select Union
            $('#upazila').change(function()  {
                var upazilaID = $(this).val();
                console.log(upazilaID);
                if(upazilaID) {
                    $.ajax({
                        url: "{{url('admin/getUnion')}}?upazila_id="+upazilaID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="union"]').empty();
                            $('#union').append('<option value="">{{__('messages.ইউনিয়ন নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="union"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="union"]').empty();
                    $('select[name="village"]').empty();
                }
            });

            // select Village
            $('#union').change(function()  {
                var unionID = $(this).val();
                console.log(unionID);
                if(unionID) {
                    $.ajax({
                        url: "{{url('admin/getVillage')}}?union_id="+unionID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="village"]').empty();
                            $('#village').append('<option value="">{{__('messages.গ্রাম নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="village"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="village"]').empty();
                }
            });
        });

        $('#spontaneous_id').select2({
            width: '100%',
            placeholder: "{{__('messages.স্বতঃস্ফূর্ত নির্বাচন করুন')}}",
            allowClear: true,
        });

        $('#topic_id').select2({
            width: '100%',
            placeholder: "{{__('messages.নির্দেশিত নির্বাচন করুন')}}",
            allowClear: true,
        });

        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#district').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#upazila').select2({
            width: '100%',
            placeholder: "{{__('messages.উপজেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#union').select2({
            width: '100%',
            placeholder: "{{__('messages.ইউনিয়ন নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#village').select2({
            width: '100%',
            placeholder: "{{__('messages.গ্রাম নির্বাচন করুন')}}",
            allowClear: true
        });
    </script>
@endsection
