@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">{{__('messages.কর্মিদল')}}</a></li>
                        <li class="breadcrumb-item"><a href="{{route('admin.groups.index')}}">{{__('messages.গ্রুপ তালিকা')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.এডিট')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                {{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}
                <form action="{{route('admin.groups.update', $group->id)}}" method="post">
                    @csrf
                    @method("PUT")
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-3">
                                <label class="col-md-2 col-sm-3 col-form-label" for="name"> {{__('messages.গ্রুপের নাম')}}<span class="text-danger">*</span></label>
                                <div class=" col-md-9 col-sm-8">
                                    <input class="form-control @error('name') is-invalid @enderror" name="name" id="name" type="text" value="{{$group->name}}" required>
                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="col-md-1 col-sm-1 px-0 pt-2">
                                </div>
                            </div>
                            <div class="mb-3 field_wrapper">
                                <div class="row mb-2">
                                    <label class="col-md-2 col-sm-3 col-form-label" for="member">{{__('messages.সদস্য')}}<span class="text-danger">*</span></label>
                                    <div id="" class="col-md-9 col-sm-8">
                                        <select class="form-select" id="member" name="member[]" multiple>
                                            <option value="">{{__('messages.সদস্য নির্বাচন করুন')}}
                                            @foreach($collectors as $key => $collector)
                                                <option value="{{$key}}" {{in_array($key , $groupMembers )? 'selected': ''}} >{{$collector}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-3">
                                <label class="col-md-2 col-sm-3 col-form-label" for="manager">{{__('messages.ম্যানেজার')}}<span class="text-danger">*</span></label>
                                <div class=" col-md-10 col-sm-9">
                                    <select class="form-select" id="manager" name="manager">
                                        <option value="">{{__('messages.ম্যানেজার নির্বাচন করুন')}}</option>
                                        @if(!empty($managers))
                                            @foreach($managers as $key => $manager)
                                                <option value="{{$key}}" {{($key == $group->manager_id)? 'selected': ''}}>{{$manager}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-md-2 col-sm-3 col-form-label" for="supervisor">{{__('messages.সুপারভাইজর')}}<span class="text-danger">*</span></label>
                                <div class=" col-md-10 col-sm-9">
                                    <select class="form-select" id="supervisor" name="supervisor">
                                        <option value="">{{__('messages.সুপারভাইজর নির্বাচন করুন')}}</option>
                                        @if(!empty($supervisors))
                                            @foreach($supervisors as $key => $supervisor)
                                                <option value="{{$key}}" {{($key == $group->supervisor_id)? 'selected': ''}}>{{$supervisor}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-md-2 col-sm-3 col-form-label" for="guide">{{__('messages.গাইড')}}<span class="text-danger">*</span></label>
                                <div class=" col-md-10 col-sm-9">
                                    <select class="form-select" id="guide" name="guide">
                                        @if(!empty($guides))
                                            @foreach($guides as $key => $guide)
                                                <option value="{{$key}}" {{($key == $group->guide_id)? 'selected': ''}}>{{$guide}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row ">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('staff-group-js')
    <script>
        $(document).ready(function(){
            $('#member').select2({
                width: '100%',
                placeholder: "{{__('messages.সদস্য নির্বাচন করুন')}}",
                allowClear: true
            });

            $('#manager').select2({
                width: '100%',
                placeholder: "{{__('messages.ম্যানেজার নির্বাচন করুন')}}",
                allowClear: true
            });

            $('#supervisor').select2({
                width: '100%',
                placeholder: "{{__('messages.সুপারভাইজর নির্বাচন করুন')}}",
                allowClear: true
            });
            $('#guide').select2({
                width: '100%',
                placeholder: "{{__('messages.গাইড নির্বাচন করুন')}}",
                allowClear: true
            });
        });
    </script>
@endsection

