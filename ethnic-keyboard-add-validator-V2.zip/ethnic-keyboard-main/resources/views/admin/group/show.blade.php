@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">{{__('messages.কর্মিদল')}}</a></li>
                        <li class="breadcrumb-item"><a href="{{route('admin.groups.index')}}">{{__('messages.গ্রুপ তালিকা')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Show</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="row mb-3">
                            <label class="col-md-2 col-sm-2 col-form-label" for="name">{{__('messages.নাম')}} </label>
                            <div class=" col-md-10 col-sm-10">
                                <strong>{{$group->name}}</strong>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-2 col-form-label" for="member">{{__('messages.সদস্য')}}</label>
                            <div class="col-md-10">
                                @foreach( $group->collectors as $collector)
                                <strong>{{$collector->name}}</strong><br>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="row mb-3">
                            <label class="col-md-2 col-sm-2 col-form-label" for="nid">{{__('messages.ম্যানেজার')}}</label>
                            <div class=" col-md-10 col-sm-10">
                                <strong>{{$group->manager->name}}</strong>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-md-2 col-sm-2 col-form-label" for="education">{{__('messages.সুপারভাইজর')}}</label>
                            <div class=" col-md-10 col-sm-10">
                                <strong>{{$group->supervisor->name}}</strong>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-2 col-sm-2 col-form-label" for="nid">{{__('messages.গাইড')}}</label>
                            <div class=" col-md-10 col-sm-10">
                                <strong>{{$group->guide->name}}</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
