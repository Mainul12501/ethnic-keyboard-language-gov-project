@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">{{__('messages.দায়িত্বপ্রাপ্ত ব্যক্তিবর্গ ')}}</a></li>
                        <li class="breadcrumb-item"><a href="{{route('admin.groups.index')}}">{{__('messages.গ্রুপ তালিকা')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.নতুন')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <form action="{{route('admin.groups.store')}}" method="post">
                    @csrf
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-3">
                                <label class="col-md-3 col-sm-3 col-form-label" for="name">{{__('messages.গ্রুপের নাম')}} <span class="text-danger">*</span></label>
                                <div class=" col-md-9 col-sm-9">
                                    <input class="form-control @error('name') is-invalid @enderror" name="name" id="name" type="text" placeholder="{{__('messages.গ্রুপের নাম')}}" value="{{old('name')}}" required>
                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="mb-3 field_wrapper">
                                <div class="row mb-2">
                                    <label class="col-md-3 col-sm-3 col-form-label" for="member">{{__('messages.সদস্য')}} <span class="text-danger">*</span></label>
                                    <div id="" class="col-md-9 col-sm-8">
                                        <select class="form-select @error('member') is-invalid @enderror" id="member" name="member[]" multiple>
                                            <option value="">{{__('messages.সদস্য নির্বাচন করুন')}}</option>
                                            @foreach($collectors as $key => $collector)
                                                <option value="{{$key}}">{{$collector}}</option>
                                            @endforeach
                                        </select>
                                        @error('member')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-3">
                                <label class="col-md-3 col-sm-3 col-form-label" for="manager">{{__('messages.ম্যানেজার')}} <span class="text-danger">*</span></label>
                                <div class=" col-md-9 col-sm-9">
                                    <select class="form-select @error('manager') is-invalid @enderror" id="manager" name="manager">
                                        <option value="">{{__('messages.ম্যানেজার নির্বাচন করুন')}}</option>
                                        @foreach($managers as $key=>$manager)
                                            <option value="{{$key}}">{{$manager}}</option>
                                        @endforeach
                                    </select>
                                    @error('manager')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-md-3 col-sm-3 col-form-label" for="supervisor">{{__('messages.সুপারভাইজর')}} <span class="text-danger">*</span></label>
                                <div class=" col-md-9 col-sm-9">
                                    <select class="form-select @error('supervisor') is-invalid @enderror" id="supervisor" name="supervisor">
                                        <option value="">{{__('messages.সুপারভাইজর নির্বাচন করুন')}}</option>
                                        @foreach($supervisors as $key => $supervisor)
                                            <option value="{{$key}}">{{$supervisor}}</option>
                                        @endforeach
                                    </select>
                                    @error('supervisor')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-md-3 col-sm-3 col-form-label" for="guide">{{__('messages.গাইড')}} <span class="text-danger">*</span></label>
                                <div class=" col-md-9 col-sm-9">
                                    <select class="form-select @error('guide') is-invalid @enderror" id="guide" name="guide">
                                        <option value="">{{__('messages.গাইড নির্বাচন করুন')}}</option>
                                        @foreach($guides as $key =>$guide)
                                            <option value="{{$key}}">{{$guide}}</option>
                                        @endforeach
                                    </select>
                                    @error('guide')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row ">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('staff-group-js')
<script>
    $(document).ready(function(){
        $('#member').select2({
            width: '100%',
            placeholder: "{{__('messages.সদস্য নির্বাচন করুন')}}",
            allowClear: true
        });


        $('#manager').select2({
            width: '100%',
            placeholder: "{{__('messages.ম্যানেজার নির্বাচন করুন')}}",
            allowClear: true
        });

        $('#supervisor').select2({
            width: '100%',
            placeholder: "{{__('messages.সুপারভাইজর নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#guide').select2({
            width: '100%',
            placeholder: "{{__('messages.গাইড নির্বাচন করুন')}}",
            allowClear: true
        });
    });
</script>
@endsection

