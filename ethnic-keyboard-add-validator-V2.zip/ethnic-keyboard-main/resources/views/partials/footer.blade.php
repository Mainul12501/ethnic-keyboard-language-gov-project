<footer class="footer">
    <div><a href="https://dream71.com">&copy; 2022 All Right Reserve.</a></div>
    <div class="footer-logo">
        <a href="https://dream71.com" target="_blank">
            <img class="footer-logo-img" src="{{asset('assets/coreui/assets/img/dream71-logo.png')}}" alt="Dream71Logo">
        </a>
    </div>
</footer>
